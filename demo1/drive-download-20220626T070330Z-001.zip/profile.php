<?php 
session_start();


	include("connection.php");
	include("functions.php");

	$user_data = check_login($con);
	$user_id = $_SESSION['user_id'];
  
	$query  = "SELECT * FROM users WHERE user_id= $user_id;";

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Profile</title>
        <link rel="stylesheet" href="profile.css">
    </head>

<figure class="snip0045 green">
	<figcaption>
		<h2><?php
			echo $_SESSION['user_id']; ?></h2>
		<p>Some things don't need the thought people give them.</p>
		<div class="icons">
			<a href="#"><i class="ion-ios-home"></i></a>
			<a href="#"><i class="ion-ios-email"></i></a>
			<a href="#"><i class="ion-ios-telephone"></i></a>
		</div>	
	</figcaption>
	<img src="studblue.png" alt="sample6"/>	
	<div class="position">Media Editor</div>
</figure>

</html>