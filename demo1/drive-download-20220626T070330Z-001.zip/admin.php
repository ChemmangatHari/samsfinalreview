<?php 
session_start();


	include("connection.php");
	include("functions.php");

	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		//$user_id = $_SESSION['user_id'];
		//$user_name = $_POST['user_name'];
		//$password = $_POST['password'];
    
		if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
		{

			//read from database
			$query = "select * from admins where user_name = '$user_name' limit 1";
			$result = mysqli_query($con, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['password'] === $password)
					{

						$_SESSION['user_id'] = $user_data['user_id'];
						header("Location: adminpage.php");
						die;
					}
				}
			}
			
			echo '<script type="text/javascript">
       window.onload = function () { alert("Wrong username or password!"); } 
</script>';
		}else
		{
			echo '<script type="text/javascript">
       window.onload = function () { alert("Wrong username or password!"); } 
</script>';
		}
	}




?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Classic Login Form Example</title>
  <link href="https://fonts.googleapis.com/css?family=Assistant:400,700" rel="stylesheet"><link rel="stylesheet" href="admin.css">

</head>
<body>
<!-- partial:index.partial.html -->
<section class='login' id='login'>
  <div class='head'>
  <h1 class='company'>TUTOR Login</h1>
  </div>
  <p class='msg'>Welcome back</p>
  <div class='form'>
    <form method="post">
  <input type="text" placeholder='Username' class='text' id='username' required><br>
  <input type="password" placeholder='••••••••••••••' class='password'><br>
  <input id="button" type="submit" value="Login"><br><br>
  <a href="adminsignup.php" class='forgot'>Sign Up</a>
    </form>
  </div>
</section>
<footer>
</footer>
<!-- partial -->
  <script  src="admin.js"></script>

</body>
</html>
